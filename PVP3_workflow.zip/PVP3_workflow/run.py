#!/usr/bin/env python3
"""Interactive driver and command line. Run python3 run.py for the menu."""
import argparse
import fcntl
import os
import shutil
import sys
from pathlib import Path

from pvp import amk, kinetics, quantum
from pvp.common import ROOT, SITES, config, read, require, seed, working


def doctor():
    cfg=config()
    for site in SITES:
        atoms = seed(site)
        print(f"{site}: {len(atoms)} 原子；C18H28N3O4；q=0，双重态；O53–C{SITES[site]}")
    for name in ["llcalcs.sh","select.sh","orca"]:
        binary = os.environ.get("ORCA_BIN",name) if name=="orca" else name
        print(f"{name}: {shutil.which(binary) or '未找到'}")
    print(f"DFT {cfg['temperature_K']} K，{cfg['orca_cores']} 核，maxcore {cfg['maxcore_mb']} MB/核")
    print("低层搜索和导出需要前两个程序；DFT 需要 ORCA 6；已完成的结果可复制整包到另一台机器继续。")


def show(site):
    snap=amk.snapshot(site)
    rows=read(snap/"edges.json")
    print(f"候选清单 {snap/'candidates.csv'}  （距离单位 Å，势垒单位 kcal/mol）")
    ranked=sorted((e for e in rows if e["usable"]),key=lambda e: (not (e["seed_like_a"] or e["seed_like_b"]),e["from_a"] if e["from_a"]!="" else float("inf")))
    for e in ranked[:20]:
        print(f"TS{e['ts']:>4}  {e['a']:>7} → {e['b']:<7}  LL势垒(A/B) {e['from_a']} / {e['from_b']}   {e['raw']}")
    require(ranked,"此批无可用通道；检查原始 RXNet、export_issues.json 和搜索日志，再决定是否补充采样")
    if len(ranked)>20:
        print(f"另有 {len(ranked)-20} 个条目，请看完整 CSV。")


def dispatch(cmd,site,ids=None,final=None,start=None):
    if cmd=="check":
        doctor()
        return
    working(site).mkdir(parents=True,exist_ok=True)
    with (working(site)/".run.lock").open("a") as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError("这一位点有任务正在运行。")
        if cmd=="search":
            amk.search(site)
        elif cmd=="import":
            amk.catalog(site,final or input("FINAL_LL 路径：").strip())
        elif cmd=="list":
            show(site)
        elif cmd=="refine":
            show(site)
            values=ids or input("输入要精修的 TS 编号，多个用空格分开：").replace(","," ").split()
            quantum.refine(site,[int(str(i).upper().removeprefix("TS")) for i in values])
        elif cmd=="review":
            root=quantum.directory(site)
            done=quantum.results(root)
            require(done,"尚无成功完成 DFT/IRC 的通道")
            quantum.make_index(root)
            good={e["ts"] for e in quantum.accepted(root)}
            print("已计算 TS（* 表示已核验）", " ".join(str(e["ts"])+("*" if e["ts"] in good else "") for e in done))
            values=ids or input("输入要核验的 TS 编号，多个用空格分开：").replace(","," ").split()
            for i in values:
                quantum.review(site,int(str(i).upper().removeprefix("TS")))
        elif cmd=="kinetics":
            kinetics.analyze(site,start)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cmd",nargs="?",choices=["check","search","import","list","refine","review","kinetics"])
    parser.add_argument("site",nargs="?",choices=list(SITES))
    parser.add_argument("--ids",nargs="+",type=int)
    parser.add_argument("--final",type=Path)
    parser.add_argument("--start")
    args=parser.parse_args()
    if args.cmd:
        require(args.site or args.cmd=="check","命令后输入 C5 或 BB")
        dispatch(args.cmd,args.site,args.ids,args.final,args.start)
        return
    print("PVP 三聚体 · 烷氧自由基单分子反应")
    ops={"1":"check","2":"search","3":"list","4":"refine","5":"review","6":"kinetics","7":"import"}
    while True:
        print("\n1 环境与结构检查   2 搜索并导出   3 查看候选   4 精修选中 TS\n5 核验频率与 IRC   6 计算 TST/KMC   7 导入已有 FINAL_LL   0 退出")
        choice=input("选择：").strip()
        if choice=="0":
            break
        try:
            require(choice in ops,"请输入菜单上的数字")
            site="C5" if choice=="1" else (input("位点 C5 或 BB [C5]：").strip().upper() or "C5")
            require(site in SITES,"位点只能是 C5 或 BB")
            dispatch(ops[choice],site)
        except (OSError,ValueError) as error:
            print("提示：",error)


if __name__=="__main__":
    try:
        main()
    except (ValueError,OSError) as error:
        sys.exit(str(error))
    except (EOFError,KeyboardInterrupt):
        sys.exit("已退出。")
