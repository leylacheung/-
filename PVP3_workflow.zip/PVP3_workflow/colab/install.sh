#!/usr/bin/env bash
# Colab CPU runtime on Linux x86_64. Record the exact upstream revision in the project.
set -euo pipefail
test -d /content || { echo 'Use this installer in Google Colab.'; exit 1; }
export DEBIAN_FRONTEND=noninteractive
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
prefix=/content/pvp_amk_install
src=/content/pvp_amk_src
apt-get -qq update
apt-get -qq install -y build-essential git curl gfortran autoconf automake gawk bc parallel sqlite3 libsqlite3-dev libblas-dev liblapack-dev libtool pkg-config dos2unix libopenblas-dev
python3 -m pip -q install ase numpy scipy matplotlib networkx joblib
if [[ ! -d "$src/.git" ]]; then
  git clone --depth=1 https://github.com/ComputationalChem-USC/AutoMeKin-X.git "$src"
fi
cd "$src"
if [[ ! -f "$prefix/.pvp_build_done" ]]; then
  autoreconf -i
  ./configure --prefix="$prefix"
  make
  make install
  test -x "$prefix/bin/llcalcs.sh"
  touch "$prefix/.pvp_build_done"
fi
git rev-parse HEAD > "$project_dir/automekin_revision.txt"
