"""Reproduce the BB seed without changing heavy-atom order or terminal groups."""
import math
from pvp.common import ROOT, seed, write, xyz


def point_from(center, toward, length):
    norm = math.dist(center, toward)
    return tuple(c + (t-c) * length/norm for c,t in zip(center,toward))


def main():
    atoms = seed("C5")
    _, ring = atoms[11]       # atom 12, C5 in central lactam
    _, backbone = atoms[9]    # atom 10, middle backbone methine
    _, oxygen = atoms[52]     # atom 53
    _, hydrogen = atoms[36]   # atom 37, originally on atom 10
    atoms[36] = ("H", point_from(ring, oxygen, 1.09))
    atoms[52] = ("O", point_from(backbone, hydrogen, 1.42))
    write(ROOT/"seeds"/"BB.xyz", xyz(atoms, "PVP3 middle backbone alkoxy O53-C10; q=0 mult=2; unoptimized seed"))
    seed("BB")
    print("BB.xyz 已生成并核对。")


if __name__ == "__main__":
    main()
