"""Small offline structure viewer for manual chemistry review."""
import json
import math
from pathlib import Path
import re

from .common import coords, require, write


def normal_mode(hess, mode_id, n):
    lines = hess.read_text(errors="replace").splitlines()
    pos = lines.index("$normal_modes")
    nrows,ncols = map(int,lines[pos+1].split())
    require(nrows==ncols==n*3, "Hessian normal mode dimensions")
    mode = {}
    col = None
    for line in lines[pos+2:]:
        parts=line.split()
        if line.startswith("$"):
            break
        if not parts:
            continue
        if all(re.fullmatch(r"\d+",x) for x in parts):
            cols=list(map(int,parts))
            col=cols.index(mode_id) if mode_id in cols else None
        elif col is not None:
            mode[int(parts[0])] = float(parts[1+col].replace("D","E"))
    require(len(mode)==3*n,"Hessian normal mode incomplete")
    vectors=[[mode[3*i+j] for j in range(3)] for i in range(n)]
    return vectors


def frames(path):
    lines=path.read_text().splitlines()
    result=[]
    i=0
    while i<len(lines):
        if not lines[i].strip():
            i+=1
            continue
        n=int(lines[i])
        require(n==53,"IRC 帧数或原子数异常")
        atoms=coords("\n".join(lines[i+2:i+2+n]))
        result.append([p for _,p in atoms])
        i+=2+n
    require(len(result)>1,"IRC 轨迹不完整")
    return result


def build(root, e, destination):
    t="TS"+str(e["ts"])
    tsdir=root/e["jobs"][t]["path"]
    atoms=coords((tsdir/"job.xyz").read_text())
    scene={"labels":[el for el,_ in atoms],"sets":{"IRC":frames(root/e["irc"]/"job_IRC_Full_trj.xyz")}}
    warning=""
    try:
        vec=normal_mode(tsdir/"job.hess",e["jobs"][t]["imag"][0][0],len(atoms))
        peak=max(math.sqrt(sum(a*a for a in v)) for v in vec)
        require(peak>0,"空的振动向量")
        scene["sets"]["TS 虚频"]=[[[a+v*0.45*math.sin(2*math.pi*k/32)/peak for a,v in zip(p,d)]
                                   for (_,p),d in zip(atoms,vec)] for k in range(32)]
    except (OSError,ValueError,IndexError,KeyError):
        warning="此 Hessian 版本需要用 orca_pltvib 查看虚频。"
    for k in ["B","F"]:
        scene["sets"]["IRC "+k]=[[p for _,p in coords((root/e["irc"]/f"job_IRC_{k}.xyz").read_text())]]
    for s,j in e["jobs"].items():
        scene["sets"][s]=[[p for _,p in coords((root/j["path"]/"job.xyz").read_text())]]
    template=Path(__file__).with_name("viewer.html").read_text()
    write(destination,template.replace("__TITLE__",t+" · "+e["a"]+" ↔ "+e["b"]).replace("__WARN__",warning).replace("__SCENE__",json.dumps(scene,ensure_ascii=False,separators=(",",":"))))
