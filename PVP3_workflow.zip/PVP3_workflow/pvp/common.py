"""File formats, per-site workspace and geometry checks (all atom IDs are 1-based)."""
import csv
import hashlib
import io
import json
import math
import os
import re
import shutil
import tempfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SITES = {"C5": 12, "BB": 10}
NUM = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?"
FORMULA = {"C": 18, "H": 28, "N": 3, "O": 4}
RADII = {"H": .31, "C": .76, "N": .71, "O": .66}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="", dir=path.parent, delete=False) as f:
        f.write(content)
    os.replace(f.name, path)


def save(path, obj):
    write(path, json.dumps(obj, indent=2, ensure_ascii=False) + "\n")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(value):
    return hashlib.sha256(value).hexdigest()


def table(path, rows, fields):
    buf = io.StringIO(newline="")
    writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    write(path, "\ufeff" + buf.getvalue())


def config():
    cfg = read(ROOT / "settings.json")
    for key in ["tasks", "iterations", "parallel", "orca_cores", "maxcore_mb",
                "irc_steps", "kmc_trajectories", "kmc_max_events"]:
        require(type(cfg[key]) is int and cfg[key] > 0, f"{key} 须为正整数")
    require(cfg["parallel"] <= cfg["tasks"], "parallel 超过 tasks")
    require(type(cfg["kmc_seed"]) is int, "kmc_seed 须为整数")
    for key in ["temperature_K", "kmc_seconds"]:
        require(math.isfinite(cfg[key]) and cfg[key] > 0, f"{key} 须为正数")
    return cfg


def working(site):
    return ROOT / "runs" / site


def coords(text):
    """Accept XYZ text or native select.sh geometry lines; reject partial frames."""
    rows = []
    for line in text.splitlines():
        parts = line.split()
        if parts and parts[0] in RADII and len(parts) == 4:
            p = tuple(float(x) for x in parts[1:])
            require(all(map(math.isfinite, p)), "坐标含非有限值")
            rows.append((parts[0], p))
    require(Counter(a for a, _ in rows) == FORMULA, "需要完整的 53 原子 PVP3 自由基坐标")
    return rows


def xyz(rows, note):
    return f"{len(rows)}\n{note}\n" + "".join(
        f"{el:2s} {x:14.8f} {y:14.8f} {z:14.8f}\n" for el, (x, y, z) in rows
    )


def bonds(rows):
    edges = set()
    for i, (el, pos) in enumerate(rows):
        for j in range(i):
            other, pos2 = rows[j]
            if math.dist(pos, pos2) < 1.22 * (RADII[el] + RADII[other]):
                edges.add((j+1, i+1))
    return edges


def seed(site):
    rows = coords((ROOT / "seeds" / f"{site}.xyz").read_text())
    graph = bonds(rows)
    center = SITES[site]
    require({a for a,b in graph if b == 53} == {center}, f"O53 与 {site} 位点不符")
    neighbors = lambda i: {b if a == i else a for a,b in graph if i in (a,b)}
    require(neighbors(12) == ({11,13,38,53} if site == "C5" else {11,13,37,38}), "环 C12 配位异常")
    require(neighbors(10) == ({9,11,17,37} if site == "C5" else {9,11,17,53}), "主链 C10 配位异常")
    require(all(len(neighbors(i)) == 1 for i, (el, _) in enumerate(rows, 1) if el == "H"), "氢的配位异常")
    return rows


def check_order(rows, reference):
    require([s for s,_ in rows] == [s for s,_ in reference], "原子序列不匹配，请核实导出体系及编号")


def executable(name, env=None):
    candidate = os.environ.get(env, "") if env else ""
    found = shutil.which(candidate or name)
    require(found, f"找不到 {name}" + (f"。请设置 {env} 为可执行文件的完整路径" if env else "。请先激活 AutoMeKin-X 环境"))
    return os.path.abspath(found)
