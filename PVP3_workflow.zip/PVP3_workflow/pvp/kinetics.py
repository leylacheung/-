"""Unimolecular Eyring TST and seeded, finite-time direct Gillespie simulation."""
import math
import random
from collections import Counter, defaultdict
from datetime import datetime

from .common import config, require, save, table
from .quantum import HARTREE_KCAL, accepted, directory

KB = 1.380649e-23      # J K^-1
PLANCK = 6.62607015e-34
R = 8.31446261815324 / 4184  # kcal mol^-1 K^-1


def rates(selected, temp):
    rows=[]
    minima={}
    for e in selected:
        for label,job in e["jobs"].items():
            if label.startswith("MIN"):
                old=minima.setdefault(label,job["path"])
                require(old==job["path"],f"{label} 引用了不同版本的 DFT 结构，请用统一的极小点重算相关通道。")
        require(abs(e["temperature_K"]-temp)<1e-6, "自由能温度与 TST 温度不一致")
        ts=e["jobs"][f"TS{e['ts']}"]["g"]
        directions=[(e["a"],e["b"])]
        if e["rev"]:
            directions.append((e["b"],e["a"]))
        for a,b in directions:
            barrier=(ts-e["jobs"][a]["g"])*HARTREE_KCAL
            require(math.isfinite(barrier) and barrier>=0,
                    f"TS{e['ts']} 相对 {a} 势垒为 {barrier:.3f}，需核对构象、热校正与能量基准")
            k=KB*temp/PLANCK * math.exp(-barrier/(R*temp))
            require(k>0 and math.isfinite(k), "速率超出可表示范围")
            rows.append(dict(ts=e["ts"],source=a,target=b,T_K=temp,deltaG_kcal_mol=barrier,k_s_inv=k))
    for r in rows:
        total=math.fsum(x["k_s_inv"] for x in rows if x["source"]==r["source"])
        r["first_event_probability"]=r["k_s_inv"]/total
    return rows


def simulate(rows, initial, seconds, count, limit, seed):
    outgoing=defaultdict(list)
    for r in rows:
        outgoing[r["source"]].append(r)
    require(initial in outgoing,"所选起点在已核验网络中没有出边")
    rng=random.Random(seed)
    totals=Counter()
    for _ in range(count):
        state, elapsed, events = initial, 0., 0
        while state in outgoing:
            choices=outgoing[state]
            total=math.fsum(x["k_s_inv"] for x in choices)
            elapsed+=rng.expovariate(total)
            if elapsed>seconds:
                break
            if events>=limit:
                state="CENSORED_event_limit"
                break
            u=rng.random()*total
            cumulative=0.
            for edge in choices:
                cumulative+=edge["k_s_inv"]
                if u<cumulative:
                    break
            state=edge["target"]
            events+=1
        totals[state]+=1
    labels=sorted({initial}|{r[k] for r in rows for k in ["source","target"]}|set(totals))
    return [dict(state=s,count=totals[s],fraction=totals[s]/count,binomial_se=math.sqrt((totals[s]/count)*(1-totals[s]/count)/count))
            for s in labels]


def analyze(site, initial):
    cfg,root=config(),directory(site)
    selected=accepted(root)
    require(selected, "尚无核验通过的通道，先选择核验。")
    rows=rates(selected,cfg["temperature_K"])
    options=sorted({r["source"] for r in rows})
    if initial is None:
        print("结合候选 xyz 和自旋选择中间重复单元起点。可选 "+", ".join(options))
        initial=input("起始 MIN 编号（如 MIN2）：").strip().upper()
    if initial.isdigit():
        initial="MIN"+initial
    states=simulate(rows,initial,cfg["kmc_seconds"],cfg["kmc_trajectories"],cfg["kmc_max_events"],cfg["kmc_seed"])
    result=root/"results"/datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    table(result/"rates.csv",rows,list(rows[0]))
    table(result/"kmc.csv",states,list(states[0]))
    save(result/"conditions.json",dict(site=site,initial=initial,settings=cfg,channels=[
        {"ts":e["ts"],"token":e["token"]} for e in selected],kappa=1,degeneracy=1))
    print(f"已核验子网络的速率与首步分支 {result/'rates.csv'}\n给定初始态和观察时间的占比 {result/'kmc.csv'}")
