"""Run a low-level search and export atom-mapped candidates via AutoMeKin select.sh."""
import math
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from .common import (NUM, ROOT, bonds, check_order, config, coords, digest, executable,
                     read, require, save, seed, table, working, write, xyz)

NODE = r"(MIN|PR)\s*(\d+)"
ROW = re.compile(rf"^\s*(?:TS\s*)?(\d+)\s+({NUM})\s+(.+?)\s*(<?-+>|<-+)\s*(.+?)\s*$", re.I)
WATCH = [(12,53), (11,12), (12,13), (10,53), (9,10), (10,17), (10,11)]


def search(site):
    cfg = config()
    seed(site)
    binary = executable("llcalcs.sh")
    require(" " not in str(working(site)), "上游 shell 脚本可能拆分空格；请把项目移到无空格路径再运行。")
    base = working(site)/"search"
    base.mkdir(parents=True, exist_ok=True)
    run = Path(tempfile.mkdtemp(prefix="batch_", dir=base))
    for ext in ["xyz", "dat"]:
        shutil.copy2(ROOT/"seeds"/f"{site}.{ext}", run)
    cmd = [binary, f"{site}.dat", *[str(cfg[k]) for k in ("tasks","iterations","parallel")]]
    save(run/"command.json", cmd)
    print(f"低层搜索目录 {run}\n日志 {run/'ll.log'}", flush=True)
    with (run/"ll.log").open("w") as log:
        result = subprocess.run(cmd, cwd=run, stdout=log, stderr=subprocess.STDOUT)
    final = run/f"FINAL_LL_{site}"
    require(result.returncode == 0 and (final/"RXNet").is_file(),
            f"未取得完整 RXNet，查看 {run/'ll.log'}；本批次现场已保存。可增加轨迹重新独立搜索。")
    catalog(site, final)


def info(path):
    if not path.is_file():
        return {}, ""
    lines = path.read_text().splitlines()
    values = {}
    for line in lines[1:]:
        if "conform" in line.lower():
            break
        row = re.fullmatch(rf"\s*(\d+)\s+({NUM})\s*", line)
        if row:
            values[int(row[1])] = float(row[2])
    return values, lines[0] if lines else ""


def edges(text):
    result = []
    for line in text.splitlines():
        if not re.match(r"^\s*(?:TS\s*)?\d", line, re.I):
            continue
        m = ROW.match(line)
        require(m, f"不识别 RXNet 行：{line}")
        number, energy, left, arrow, right = m.groups()
        def node(raw):
            entry = re.match(NODE, raw.strip(), re.I)
            require(entry, f"不识别端点：{raw}")
            return entry[1].upper() + str(int(entry[2]))
        a, b = node(left), node(right)
        if (a.startswith("PR") and b.startswith("MIN")) or arrow.endswith("-"):
            a, b = b, a
        result.append(dict(ts=int(number), a=a, b=b, reversible="<" in arrow and ">" in arrow,
                           relative=float(energy), raw=line.strip()))
    require(len({e["ts"] for e in result}) == len(result), "RXNet 有重复 TS 编号")
    return result


def export(final, name, dest, reference, select):
    typ, num = re.fullmatch(r"(MIN|TS)(\d+)", name).groups()
    p = subprocess.run([select, final.name, "geom", typ.lower(), num],
                       cwd=final.parent, capture_output=True, text=True)
    require(p.returncode == 0, f"{name} 导出失败：{p.stderr[-300:]}")
    atoms = coords(p.stdout)
    check_order(atoms, reference)
    write(dest/f"{name}.xyz", xyz(atoms, name))
    return atoms


def snapshot(site):
    root = working(site)
    require((root/"current.json").exists(), "请先运行搜索并导出候选。")
    return root/"catalogs"/read(root/"current.json")["snapshot"]


def catalog(site, directory):
    final = Path(directory).expanduser().resolve()
    require(final.name == f"FINAL_LL_{site}", f"请指定 FINAL_LL_{site} 目录，并保留其完整内容")
    reference = seed(site)
    source_files = [final/n for n in ["RXNet","min.db","ts.db","MINinfo","TSinfo"]]
    require(all(p.is_file() for p in source_files[:3]), "需保留 RXNet、min.db 和 ts.db")
    key = digest("".join(digest(p.read_bytes()) for p in source_files if p.exists()).encode())[:16]
    base = working(site)/"catalogs"
    dest = base/key
    if (dest/"export_issues.json").is_file():
        dest = Path(tempfile.mkdtemp(prefix=key+"_retry_",dir=base))
        dest.rmdir()
        key = dest.name
    if not (dest/"edges.json").is_file():
        select = executable("select.sh")
        base.mkdir(parents=True, exist_ok=True)
        tmp = Path(tempfile.mkdtemp(dir=base, prefix="export_"))
        rxnet = source_files[0].read_text()
        rows = edges(rxnet)
        require(rows, f"RXNet 中没有过渡态；查看 {final.parent/'ll.log'} 并增加搜索量。")
        states = sorted({s for e in rows for s in (e["a"],e["b"]) if s.startswith("MIN")})
        ids = [f"TS{e['ts']}" for e in rows if e["a"].startswith("MIN") and e["a"] != e["b"]]
        geometries, issues = {}, {}
        for label in states+ids:
            try:
                geometries[label] = export(final,label,tmp/"xyz",reference,select)
            except (OSError,ValueError) as exc:
                issues[label] = str(exc)
        if issues:
            save(tmp/"export_issues.json",issues)
            print("部分几何导出失败；见 export_issues.json。可用的其他通道会继续导出。")
        for filename in ["RXNet","MINinfo","TSinfo","convergence.txt"]:
            if (final/filename).exists():
                shutil.copy2(final/filename, tmp/filename)
        em, hm = info(final/"MINinfo")
        et, ht = info(final/"TSinfo")
        unit = lambda s: re.search(r"(D[GEH])\s*\(\s*kcal/mol\s*\)", s, re.I)
        same = unit(hm) and unit(ht) and unit(hm)[1].upper() == unit(ht)[1].upper()
        root_graph = bonds(reference)
        for edge in rows:
            a,b,n = edge["a"],edge["b"],edge["ts"]
            required = [f"TS{n}"]+[label for label in (a,b) if label.startswith("MIN")]
            edge["usable"] = a.startswith("MIN") and a != b and all(label in geometries for label in required)
            edge["export_issue"] = " | ".join(issues[label] for label in required if label in issues)
            for keyname, state in [("from_a",a),("from_b",b)]:
                number = int(state[3:]) if state.startswith("MIN") else None
                edge[keyname] = round(et[n]-em[number],3) if same and n in et and number in em else ""
            edge["seed_like_a"] = a in geometries and bonds(geometries[a]) == root_graph
            edge["seed_like_b"] = b in geometries and bonds(geometries[b]) == root_graph
            edge["ll_quantity"] = unit(ht)[1].upper() if same else ""
            if a in geometries and f"TS{n}" in geometries:
                def distance(atoms, pair):
                    i,j = pair
                    return math.dist(atoms[i-1][1], atoms[j-1][1])
                ts_atoms = geometries[f"TS{n}"]
                edge["distances"] = " | ".join(f"{i}-{j}: {distance(geometries[a],(i,j)):.2f}>{distance(ts_atoms,(i,j)):.2f}"
                                               for i,j in WATCH)
            else:
                edge["distances"] = ""
        show = sorted(rows, key=lambda e:(not e["usable"],not (e["seed_like_a"] or e["seed_like_b"]),e["from_a"] if e["from_a"] != "" else math.inf))
        table(tmp/"candidates.csv",show,["ts","a","b","raw","usable","seed_like_a","seed_like_b","ll_quantity","relative","from_a","from_b","distances","export_issue"])
        save(tmp/"edges.json", rows)
        tmp.rename(dest)
    save(working(site)/"current.json", {"snapshot":key})
    print(f"候选清单 {dest/'candidates.csv'}\n低层结构 {dest/'xyz'}")
    return dest
