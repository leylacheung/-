"""Selective ORCA 6 refinement, doublet frequency checks and bidirectional IRC review."""
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from .viewer import build
from .amk import snapshot
from .common import (NUM, bonds, check_order, config, coords, digest, executable, read,
                     require, save, seed, table, write, xyz)

LEVEL = "UKS B3LYP D3BJ def2-TZVP def2/J RIJCOSX DEFGRID3 TightSCF"
HARTREE_KCAL = 627.5094740631


def directory(site):
    cfg = config()
    key = digest(repr((LEVEL, cfg["temperature_K"],cfg["irc_steps"])).encode())[:12]
    return snapshot(site)/"dft"/key


def inp(kind, atoms, cfg):
    action = {"MIN":"TightOpt Freq", "TS":"TightOpt OptTS Freq", "IRC":"IRC"}[kind]
    # TightOpt and OptTS both assign optimization options. Put OptTS last to select the saddle optimizer.
    data = [f"! {LEVEL} {action}",f"%maxcore {cfg['maxcore_mb']}"]
    if cfg["orca_cores"] > 1:
        data.append(f"%pal nprocs {cfg['orca_cores']} end")
    if kind != "IRC":
        data.extend([f"%freq Temp {cfg['temperature_K']}\n Pressure 1.0\nend",
                     "%geom\n MaxIter 250" + ("\n Calc_Hess true\n Recalc_Hess 10" if kind=="TS" else "") + "\nend"])
    else:
        data.append(f'%irc\n Direction both\n MaxIter {cfg["irc_steps"]}\n InitHess read\n Hess_Filename "start.hess"\nend')
    body = xyz(atoms, "").splitlines()[2:]
    return "\n".join(data + ["* xyz 0 2", *body, "*", ""])


def thermochemistry(text, kind, temp):
    require("ORCA TERMINATED NORMALLY" in text and "THE OPTIMIZATION HAS CONVERGED" in text.upper(),
            "未检测到 ORCA 正常结束及几何收敛")
    blocks = re.split(r"(?im)^\s*VIBRATIONAL FREQUENCIES\s*$", text)
    require(len(blocks)>1, "缺振动频率")
    block = re.split(r"(?im)^\s*NORMAL MODES\s*$",blocks[-1])[0]
    modes = [(int(i),float(f)) for i,f in re.findall(rf"(?m)^\s*(\d+):\s*({NUM})\s+cm\*\*-1",block)]
    require([i for i,_ in modes] == list(range(159)), "频率表应有 3N=159 个模式")
    imag = [(i,f) for i,f in modes if f < 0]
    require(len(imag) == int(kind=="TS"), f"{kind} 虚频数为 {len(imag)}，请复核并重新优化；{imag}")
    thermo = re.split(r"(?i)THERMOCHEMISTRY AT", text)[-1]
    gs = re.findall(rf"(?im)^\s*Final Gibbs free energy\s*(?:\.+\s*)?({NUM})\s+Eh\b",thermo)
    ts = re.findall(rf"(?im)^\s*Temperature\s*\.+\s*({NUM})\s*K\b",thermo)
    ps = re.findall(rf"(?im)^\s*Pressure\s*\.+\s*({NUM})\s*atm\b",thermo)
    require(len(gs)==1 and ts and ps and abs(float(ts[-1])-temp)<.011 and abs(float(ps[-1])-1)<.002,
            "缺少指定温度、1 atm 下唯一的 Final Gibbs free energy")
    spin = re.findall(rf"(?i)Expectation value of\s*<S\*\*2>\s*[:=]\s*({NUM})",text)
    return dict(g=float(gs[0]), imag=imag, s2=float(spin[-1]) if spin else None)


def job(root, kind, atoms, binary, cfg, hess=None):
    text = inp(kind, atoms, cfg)
    key = digest(text.encode() + (hess.read_bytes() if hess else b""))[:16]
    folder = root/key
    folder.mkdir(parents=True, exist_ok=True)
    done = folder/"done.json"
    if done.exists():
        attempt = folder/read(done)["attempt"]
    else:
        attempt = Path(tempfile.mkdtemp(prefix="try_", dir=folder))
        write(attempt/"job.inp", text)
        if hess:
            shutil.copy2(hess,attempt/"start.hess")
        print(f"ORCA {kind}   {attempt}", flush=True)
        with (attempt/"job.out").open("w") as log:
            rc = subprocess.run([binary,"job.inp"],cwd=attempt,stdout=log,stderr=subprocess.STDOUT).returncode
        require(rc==0, f"ORCA 返回 {rc}，查看 {attempt/'job.out'}")
    output = (attempt/"job.out").read_text(errors="replace")
    if kind == "IRC":
        require("ORCA TERMINATED NORMALLY" in output and "IRC PATH SUMMARY" in output.upper(),
                f"缺完整 IRC 汇总，查看 {attempt/'job.out'}")
        require(len(re.findall(r"(?i)THE\s+IRC\s+HAS\s+CONVERGED",output))>=2,
                f"未检测到双向 IRC 均收敛。查看 {attempt/'job.out'}，必要时增加 irc_steps。")
        for suffix in ["F.xyz","B.xyz","Full_trj.xyz"]:
            p = attempt/("job_IRC_"+suffix)
            require(p.is_file() and p.stat().st_size>0, f"缺失 {p}")
            if suffix != "Full_trj.xyz":
                check_order(coords(p.read_text()), atoms)
        data = {}
    else:
        data = thermochemistry(output,kind,cfg["temperature_K"])
        check_order(coords((attempt/"job.xyz").read_text()),atoms)
        if kind=="TS":
            require((attempt/"job.hess").is_file(), "缺少 TS Hessian 文件")
    save(done,{"attempt":attempt.name})
    return attempt,data


def results(root):
    return [read(p) for p in sorted(root.glob("channels/TS*/evidence.json"))]


def fingerprint(files, info):
    hashes = [digest(p.read_bytes()) for p in files]
    return digest(("|".join(hashes)+repr(info)).encode())


def refine(site, ids):
    cfg, snap, root = config(), snapshot(site), directory(site)
    binary = executable("orca","ORCA_BIN")
    network = {e["ts"]:e for e in read(snap/"edges.json")}
    require(ids and all(n in network and network[n]["usable"] for n in ids), "选择不同端点且含单分子 MIN 的有效 TS 编号")
    failures = []
    for n in dict.fromkeys(ids):
        t = f"TS{n}"
        rel = lambda path: str(path.relative_to(root))
        channel = root/"channels"/t
        # Mark an older computation ineligible while its replacement is in progress.
        evidence = channel/"evidence.json"
        if evidence.exists():
            evidence.unlink()
        try:
            e = network[n]
            def structure(name):
                original = coords((snap/"xyz"/(name+".xyz")).read_text())
                replacement = root/"overrides"/(name+".xyz")
                if not replacement.exists():
                    return original
                candidate = coords(replacement.read_text())
                check_order(candidate,original)
                return candidate
            minima = [e["a"]] + ([e["b"]] if e["b"].startswith("MIN") else [])
            jobs = {}
            for label in minima+[t]:
                kind = "TS" if label == t else "MIN"
                path, data = job(root/"jobs"/label,kind,structure(label),binary,cfg)
                jobs[label] = dict(path=rel(path),**data)
            ts_path = root/jobs[t]["path"]
            opt_ts = coords((ts_path/"job.xyz").read_text())
            irc, _ = job(root/"jobs"/(t+"_IRC"),"IRC",opt_ts,binary,cfg,ts_path/"job.hess")
            ends = {k:coords((irc/f"job_IRC_{k}.xyz").read_text()) for k in ["B","F"]}
            eq = {s:bonds(coords((root/jobs[s]["path"]/"job.xyz").read_text())) for s in minima}
            hint = {k:{s:len(bonds(atoms)^g) for s,g in eq.items()} for k,atoms in ends.items()}
            files = [root/v["path"]/f for v in jobs.values() for f in ["job.out","job.xyz"]]
            files += [ts_path/"job.hess"] + [irc/f for f in ("job.out","job_IRC_B.xyz","job_IRC_F.xyz","job_IRC_Full_trj.xyz")]
            ev = dict(ts=n, a=e["a"],b=e["b"],raw=e["raw"], rev=e["reversible"] and len(minima)==2,
                      jobs=jobs, irc=rel(irc), graph_differences=hint, files=list(map(rel,files)),
                      level=LEVEL, temperature_K=cfg["temperature_K"])
            ev["token"] = fingerprint(files,(ev["a"],ev["b"],ev["rev"],ev["temperature_K"]))
            build(root,ev,channel/"view.html")
            save(evidence,ev)
            print(f"{t} 计算完成，等待核验。")
        except (ValueError,OSError) as exc:
            failures.append(f"{t} — {exc}")
    if results(root):
        make_index(root)
    require(not failures, "\n".join(failures))


def make_index(root):
    lines = []
    for e in results(root):
        t = "TS"+str(e["ts"])
        a = e["a"]
        jobs = e["jobs"]
        val = jobs[t]
        lines.append(dict(ts=t, raw=e["raw"], from_a=e["a"], to_b=e["b"],
                          dg_a_kcal=round((val["g"]-jobs[a]["g"])*HARTREE_KCAL,4),
                          mode=val["imag"][0][0], imag_cm=val["imag"][0][1],
                          s2_TS=val["s2"],s2_A=jobs[a]["s2"],
                          s2_B=jobs[e["b"]]["s2"] if e["b"] in jobs else "",
                          viewer=f"channels/{t}/view.html", mode_hess=val["path"]+"/job.hess",irc_path=e["irc"]+"/job_IRC_Full_trj.xyz",
                          irc_log=e["irc"]+"/job.out", graph_diff=str(e["graph_differences"])))
    path = root/"review.csv"
    table(path,lines,list(lines[0]))
    print(f"核验清单 {path}")


def review(site, number):
    root = directory(site)
    file = root/"channels"/f"TS{number}"/"evidence.json"
    require(file.is_file(),"该通道尚未完成 DFT、频率与双向 IRC")
    e = read(file)
    ts = e["jobs"][f"TS{number}"]
    print(f"用浏览器打开 {file.with_name('view.html')}")
    print(f"原始通道 {e['raw']}\n虚频模式 {ts['imag']}，TS <S²> {ts['s2']}")
    for name,data in e["jobs"].items():
        print(f"{name}   {root/data['path']}/job.xyz   <S²>={data['s2']}")
    print(f"IRC 轨迹与日志目录 {root/e['irc']}\nF/B 端点与 DFT 极小点的成键差异数（仅作定位）{e['graph_differences']}")
    print("用可视化软件查看 TS 虚频振动和 IRC 轨迹；核对两个方向收敛、端点对应同一构象、自由基自旋密度、碎片身份。")
    mode_command = f"orca_pltvib job.hess {ts['imag'][0][0]}"
    print(f"在 TS 的 job.hess 所在目录可运行 {mode_command}")
    direction = input(f"确认后输入对应 {e['a']} 的方向 F 或 B；跳过按回车，撤销输入 X：").strip().upper()
    approval = file.with_name("accepted.json")
    if direction == "X":
        if approval.exists():
            approval.unlink()
        return
    if not direction:
        return
    require(direction in {"F","B"},"方向只接受 F 或 B")
    note = input("记录振动涉及的原子号、另一端产物/构象、自旋及 IRC 判据：").strip()
    require(note,"需要核验记录")
    save(approval,dict(token=e["token"],reactant_side=direction,note=note))
    print("已记录该通道的核验。")


def accepted(root):
    selected=[]
    for e in results(root):
        approval=root/"channels"/f"TS{e['ts']}"/"accepted.json"
        if not approval.exists():
            continue
        actual = fingerprint([root/p for p in e["files"]],(e["a"],e["b"],e["rev"],e["temperature_K"]))
        require(actual==e["token"],f"TS{e['ts']} 计算文件改变，请重新计算并核验")
        if read(approval)["token"]==actual:
            selected.append(e)
    return selected
